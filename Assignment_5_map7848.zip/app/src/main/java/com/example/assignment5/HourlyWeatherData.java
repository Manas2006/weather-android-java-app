package com.example.assignment5;

import java.io.Serializable;

/**
 * Data model for hourly weather data within a day.
 */
public class HourlyWeatherData implements Serializable {
    public final String time;           // ISO time string
    public final double temperature;    // Temperature in Fahrenheit
    public final Double humidity;       // Humidity percentage (nullable)
    public final Double windSpeed;      // Wind speed in mph (nullable)
    public final Double rain;           // Rain in mm (nullable)
    public final Double pressure;       // Pressure in hPa (nullable)
    public final Double visibility;     // Visibility in km (nullable)

    public HourlyWeatherData(String time, double temperature, Double humidity, 
                             Double windSpeed, Double rain, Double pressure, Double visibility) {
        this.time = time;
        this.temperature = temperature;
        this.humidity = humidity;
        this.windSpeed = windSpeed;
        this.rain = rain;
        this.pressure = pressure;
        this.visibility = visibility;
    }
}

