package com.example.assignment5;

import java.io.Serializable;

/**
 * Data model for a city.
 */
public class City implements Serializable {
    public final String name;
    public final String state;
    public final double latitude;
    public final double longitude;

    public City(String name, String state, double latitude, double longitude) {
        this.name = name;
        this.state = state;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getDisplayName() {
        return name + ", " + state;
    }
}

