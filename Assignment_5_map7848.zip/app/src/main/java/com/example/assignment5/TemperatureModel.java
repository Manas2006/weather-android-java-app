package com.example.assignment5;

import java.io.Serializable;

/**
 * Data class to store trained temperature prediction model parameters.
 * Stores the linear regression coefficients: y = m*x + b
 */
public class TemperatureModel implements Serializable {
    public final double slope;        // m in y = mx + b
    public final double intercept;    // b in y = mx + b
    public final long trainingDate;   // Timestamp when model was trained
    public final int dataPointCount;  // Number of data points used for training

    public TemperatureModel(double slope, double intercept, long trainingDate, int dataPointCount) {
        this.slope = slope;
        this.intercept = intercept;
        this.trainingDate = trainingDate;
        this.dataPointCount = dataPointCount;
    }

    /**
     * Predict temperature for a given day of year.
     * @param dayOfYear Day of year (1-365)
     * @return Predicted temperature in Fahrenheit
     */
    public double predict(int dayOfYear) {
        return slope * dayOfYear + intercept;
    }

    /**
     * Check if model is stale and needs retraining.
     * @param maxAgeDays Maximum age in days before retraining is needed
     * @return true if model should be retrained
     */
    public boolean isStale(int maxAgeDays) {
        long currentTime = System.currentTimeMillis();
        long ageMillis = currentTime - trainingDate;
        long ageDays = ageMillis / (24 * 60 * 60 * 1000);
        return ageDays >= maxAgeDays;
    }
}

