package com.example.assignment5;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DetailedWeatherActivity extends AppCompatActivity {

    private LineChart tempChart;
    private LineChart humidityChart;
    private LineChart windChart;
    private LineChart rainChart;
    private TextView dayLabel;
    private TextView avgTempText;
    private TextView avgHumidityText;
    private TextView avgWindText;
    private TextView totalRainText;
    private ImageButton backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_weather);

        // Get the day index and hourly data from intent
        int dayIndex = getIntent().getIntExtra("dayIndex", 0);
        String dayLabelStr = getIntent().getStringExtra("dayLabel");
        ArrayList<HourlyWeatherData> hourlyData = (ArrayList<HourlyWeatherData>) 
            getIntent().getSerializableExtra("hourlyData");

        initializeViews();
        
        // Set up back button
        backButton.setOnClickListener(v -> finish());
        
        if (hourlyData != null && !hourlyData.isEmpty()) {
            dayLabel.setText(dayLabelStr != null ? dayLabelStr : "Day Details");
            setupCharts(hourlyData);
            calculateAndDisplayAverages(hourlyData);
        }
    }

    private void initializeViews() {
        backButton = findViewById(R.id.backButton);
        dayLabel = findViewById(R.id.detailedDayLabel);
        avgTempText = findViewById(R.id.avgTempText);
        avgHumidityText = findViewById(R.id.avgHumidityText);
        avgWindText = findViewById(R.id.avgWindText);
        totalRainText = findViewById(R.id.totalRainText);
        
        tempChart = findViewById(R.id.tempChart);
        humidityChart = findViewById(R.id.humidityChart);
        windChart = findViewById(R.id.windChart);
        rainChart = findViewById(R.id.rainChart);
    }

    private void setupCharts(List<HourlyWeatherData> hourlyData) {
        // Temperature chart
        setupTemperatureChart(hourlyData);
        
        // Humidity chart
        if (hourlyData.get(0).humidity != null) {
            setupHumidityChart(hourlyData);
        } else {
            humidityChart.setVisibility(android.view.View.GONE);
        }
        
        // Wind chart
        if (hourlyData.get(0).windSpeed != null) {
            setupWindChart(hourlyData);
        } else {
            windChart.setVisibility(android.view.View.GONE);
        }
        
        // Rain chart
        if (hourlyData.get(0).rain != null) {
            setupRainChart(hourlyData);
        } else {
            rainChart.setVisibility(android.view.View.GONE);
        }
    }

    private void setupTemperatureChart(List<HourlyWeatherData> hourlyData) {
        ArrayList<Entry> entries = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        
        for (int i = 0; i < hourlyData.size(); i++) {
            HourlyWeatherData data = hourlyData.get(i);
            entries.add(new Entry(i, (float) data.temperature));
            // Extract hour from time string (format: "2024-01-15T14:00")
            String timeStr = data.time;
            if (timeStr != null && timeStr.length() > 13) {
                String hour = timeStr.substring(11, 13);
                labels.add(hour + ":00");
            } else {
                labels.add(String.valueOf(i));
            }
        }
        
        LineDataSet dataSet = new LineDataSet(entries, "Temperature (°F)");
        dataSet.setColor(0xFFE74C3C);
        dataSet.setLineWidth(2f);
        dataSet.setCircleColor(0xFFE74C3C);
        dataSet.setCircleRadius(4f);
        dataSet.setValueTextSize(10f);
        
        LineData lineData = new LineData(dataSet);
        tempChart.setData(lineData);
        tempChart.getDescription().setText("Hourly Temperature");
        tempChart.getXAxis().setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int index = (int) value;
                if (index >= 0 && index < labels.size()) {
                    return labels.get(index);
                }
                return "";
            }
        });
        tempChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        tempChart.getXAxis().setLabelRotationAngle(-45f);
        tempChart.invalidate();
    }

    private void setupHumidityChart(List<HourlyWeatherData> hourlyData) {
        ArrayList<Entry> entries = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        
        for (int i = 0; i < hourlyData.size(); i++) {
            HourlyWeatherData data = hourlyData.get(i);
            if (data.humidity != null) {
                entries.add(new Entry(i, data.humidity.floatValue()));
                String timeStr = data.time;
                if (timeStr != null && timeStr.length() > 13) {
                    labels.add(timeStr.substring(11, 13) + ":00");
                } else {
                    labels.add(String.valueOf(i));
                }
            }
        }
        
        LineDataSet dataSet = new LineDataSet(entries, "Humidity (%)");
        dataSet.setColor(0xFF3498DB);
        dataSet.setLineWidth(2f);
        dataSet.setCircleColor(0xFF3498DB);
        dataSet.setCircleRadius(4f);
        
        LineData lineData = new LineData(dataSet);
        humidityChart.setData(lineData);
        humidityChart.getDescription().setText("Hourly Humidity");
        humidityChart.getXAxis().setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int index = (int) value;
                if (index >= 0 && index < labels.size()) {
                    return labels.get(index);
                }
                return "";
            }
        });
        humidityChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        humidityChart.invalidate();
    }

    private void setupWindChart(List<HourlyWeatherData> hourlyData) {
        ArrayList<Entry> entries = new ArrayList<>();
        
        for (int i = 0; i < hourlyData.size(); i++) {
            HourlyWeatherData data = hourlyData.get(i);
            if (data.windSpeed != null) {
                entries.add(new Entry(i, data.windSpeed.floatValue()));
            }
        }
        
        LineDataSet dataSet = new LineDataSet(entries, "Wind Speed (mph)");
        dataSet.setColor(0xFF2ECC71);
        dataSet.setLineWidth(2f);
        dataSet.setCircleColor(0xFF2ECC71);
        dataSet.setCircleRadius(4f);
        
        LineData lineData = new LineData(dataSet);
        windChart.setData(lineData);
        windChart.getDescription().setText("Hourly Wind Speed");
        windChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        windChart.invalidate();
    }

    private void setupRainChart(List<HourlyWeatherData> hourlyData) {
        ArrayList<Entry> entries = new ArrayList<>();
        
        for (int i = 0; i < hourlyData.size(); i++) {
            HourlyWeatherData data = hourlyData.get(i);
            if (data.rain != null) {
                entries.add(new Entry(i, data.rain.floatValue()));
            }
        }
        
        LineDataSet dataSet = new LineDataSet(entries, "Rain (mm)");
        dataSet.setColor(0xFF9B59B6);
        dataSet.setLineWidth(2f);
        dataSet.setCircleColor(0xFF9B59B6);
        dataSet.setCircleRadius(4f);
        
        LineData lineData = new LineData(dataSet);
        rainChart.setData(lineData);
        rainChart.getDescription().setText("Hourly Precipitation");
        rainChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        rainChart.invalidate();
    }

    private void calculateAndDisplayAverages(List<HourlyWeatherData> hourlyData) {
        double tempSum = 0;
        double humiditySum = 0;
        double windSum = 0;
        double rainSum = 0;
        int humidityCount = 0;
        int windCount = 0;
        int rainCount = 0;
        
        for (HourlyWeatherData data : hourlyData) {
            tempSum += data.temperature;
            if (data.humidity != null) {
                humiditySum += data.humidity;
                humidityCount++;
            }
            if (data.windSpeed != null) {
                windSum += data.windSpeed;
                windCount++;
            }
            if (data.rain != null) {
                rainSum += data.rain;
                rainCount++;
            }
        }
        
        double avgTemp = tempSum / hourlyData.size();
        avgTempText.setText(String.format(Locale.US, "Average: %.1f°F", avgTemp));
        
        if (humidityCount > 0) {
            double avgHumidity = humiditySum / humidityCount;
            avgHumidityText.setText(String.format(Locale.US, "Average: %.1f%%", avgHumidity));
        } else {
            avgHumidityText.setText("Average: N/A");
        }
        
        if (windCount > 0) {
            double avgWind = windSum / windCount;
            avgWindText.setText(String.format(Locale.US, "Average: %.1f mph", avgWind));
        } else {
            avgWindText.setText("Average: N/A");
        }
        
        if (rainCount > 0) {
            totalRainText.setText(String.format(Locale.US, "Total: %.2f mm", rainSum));
        } else {
            totalRainText.setText("Total: 0 mm");
        }
    }
}


