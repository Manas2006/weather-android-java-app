package com.example.assignment5;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Main activity for the weather forecast app.
 * Note: Uses AsyncTask which is deprecated in API 30+, but acceptable for this assignment (min SDK 24).
 */
@SuppressWarnings("deprecation")
public class MainActivity extends AppCompatActivity {

    // View references
    private ProgressBar progressBar;
    private TextView errorTextView;
    private TextView cityLabel;
    private TextView todayBigTemp;
    private TextView subtitleText;
    private ImageButton refreshButton;
    
    // Prediction UI
    private Button predictButton;
    private ProgressBar predictionProgressBar;
    private TextView predictionTextView;
    
    // Arrays for day labels, temperatures, humidity, and wind
    private TextView[] dayLabels;
    private TextView[] dayTemps;
    private TextView[] dayHumidities;
    private TextView[] dayWinds;
    private View[] dayCards;  // Card views for click handling
    
    // City management
    private List<City> cities;
    private City currentCity;
    private SharedPreferences prefs;
    private static final String PREFS_NAME = "WeatherPrefs";
    private static final String KEY_CURRENT_CITY = "currentCity";
    private static final String KEY_CITIES = "cities";
    
    // Model persistence keys (per-city)
    private static final String KEY_MODEL_SLOPE = "model_slope_";
    private static final String KEY_MODEL_INTERCEPT = "model_intercept_";
    private static final String KEY_MODEL_TRAINING_DATE = "model_training_date_";
    private static final String KEY_MODEL_DATA_COUNT = "model_data_count_";
    private static final String KEY_MODEL_CITY = "model_city_";
    private static final int MODEL_RETRAIN_DAYS = 7; // Retrain weekly
    
    // Current forecasts (for passing to detailed view)
    private List<DailyForecast> currentForecasts;
    
    // Cached model for fast predictions
    private TemperatureModel cachedModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize view references
        initializeViews();
        
        // Initialize city management
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        initializeCities();
        
        // Load cached model if available
        boolean modelLoaded = loadCachedModel();
        if (!modelLoaded) {
            Log.d("TemperaturePrediction", "No valid cached model found, will train on first prediction");
        }
        
        // Set refresh button click listener
        refreshButton.setOnClickListener(v -> startForecastFetch());
        
        // Set predict button click listener
        predictButton.setOnClickListener(v -> startPrediction());
        
        // Add city management button (using cityLabel as clickable)
        cityLabel.setOnClickListener(v -> showCityManagementDialog());
        
        // Start fetching forecast data
        startForecastFetch();
    }
    
    /**
     * Get a unique key for the current city (for model persistence).
     */
    private String getCityKey() {
        if (currentCity == null) {
            return "default";
        }
        // Use city name and coordinates to create unique key
        return currentCity.name + "_" + currentCity.latitude + "_" + currentCity.longitude;
    }
    
    /**
     * Load cached model from SharedPreferences for the current city.
     * Returns true if a valid model was loaded.
     */
    private boolean loadCachedModel() {
        try {
            if (currentCity == null) {
                Log.d("TemperaturePrediction", "No current city, cannot load model");
                return false;
            }
            
            String cityKey = getCityKey();
            String slopeKey = KEY_MODEL_SLOPE + cityKey;
            String interceptKey = KEY_MODEL_INTERCEPT + cityKey;
            String dateKey = KEY_MODEL_TRAINING_DATE + cityKey;
            String countKey = KEY_MODEL_DATA_COUNT + cityKey;
            String cityNameKey = KEY_MODEL_CITY + cityKey;
            
            if (!prefs.contains(slopeKey)) {
                Log.d("TemperaturePrediction", "No cached model found for city: " + currentCity.getDisplayName());
                return false;
            }
            
            // Verify this model is for the current city
            String savedCityName = prefs.getString(cityNameKey, "");
            if (!savedCityName.equals(currentCity.getDisplayName())) {
                Log.d("TemperaturePrediction", "Cached model is for different city: " + savedCityName + " vs " + currentCity.getDisplayName());
                return false;
            }
            
            double slope = Double.longBitsToDouble(prefs.getLong(slopeKey, 0));
            double intercept = Double.longBitsToDouble(prefs.getLong(interceptKey, 0));
            long trainingDate = prefs.getLong(dateKey, 0);
            int dataCount = prefs.getInt(countKey, 0);
            
            cachedModel = new TemperatureModel(slope, intercept, trainingDate, dataCount);
            
            Log.d("TemperaturePrediction", "Loaded cached model for " + currentCity.getDisplayName() + 
                  ": slope=" + slope + ", intercept=" + intercept + ", trainingDate=" + trainingDate + ", dataCount=" + dataCount);
            
            // Check if model is stale
            if (cachedModel.isStale(MODEL_RETRAIN_DAYS)) {
                Log.d("TemperaturePrediction", "Cached model is stale (older than " + MODEL_RETRAIN_DAYS + " days), will retrain");
                cachedModel = null;
                return false;
            }
            
            Log.d("TemperaturePrediction", "Cached model is valid and ready to use for " + currentCity.getDisplayName());
            return true;
            
        } catch (Exception e) {
            Log.e("TemperaturePrediction", "Error loading cached model", e);
            cachedModel = null;
            return false;
        }
    }
    
    /**
     * Save model to SharedPreferences for the current city.
     */
    private void saveModel(TemperatureModel model) {
        try {
            if (currentCity == null) {
                Log.e("TemperaturePrediction", "Cannot save model: no current city");
                return;
            }
            
            String cityKey = getCityKey();
            String slopeKey = KEY_MODEL_SLOPE + cityKey;
            String interceptKey = KEY_MODEL_INTERCEPT + cityKey;
            String dateKey = KEY_MODEL_TRAINING_DATE + cityKey;
            String countKey = KEY_MODEL_DATA_COUNT + cityKey;
            String cityNameKey = KEY_MODEL_CITY + cityKey;
            
            SharedPreferences.Editor editor = prefs.edit();
            editor.putLong(slopeKey, Double.doubleToLongBits(model.slope));
            editor.putLong(interceptKey, Double.doubleToLongBits(model.intercept));
            editor.putLong(dateKey, model.trainingDate);
            editor.putInt(countKey, model.dataPointCount);
            editor.putString(cityNameKey, currentCity.getDisplayName());
            editor.apply();
            
            Log.d("TemperaturePrediction", "Saved model for " + currentCity.getDisplayName() + 
                  ": slope=" + model.slope + ", intercept=" + model.intercept + 
                  ", trainingDate=" + model.trainingDate + ", dataCount=" + model.dataPointCount);
            
            cachedModel = model;
            
        } catch (Exception e) {
            Log.e("TemperaturePrediction", "Error saving model", e);
        }
    }
    
    /**
     * Train a new model from historical data.
     * Returns the trained model or null if training failed.
     */
    private TemperatureModel trainModel(List<HistoricalDataPoint> historicalData) {
        try {
            Log.d("TemperaturePrediction", "Training model with " + historicalData.size() + " data points");
            
            // Validate we have at least 100 data points
            if (historicalData.size() < 100) {
                Log.e("TemperaturePrediction", "Insufficient data for training: " + historicalData.size() + " points");
                return null;
            }
            
            // Calculate linear regression: y = mx + b
            double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
            int n = historicalData.size();
            
            for (HistoricalDataPoint point : historicalData) {
                double x = point.dayOfYear;
                double y = point.temperature;
                sumX += x;
                sumY += y;
                sumXY += x * y;
                sumX2 += x * x;
            }
            
            Log.d("TemperaturePrediction", "Training stats - SumX: " + sumX + ", SumY: " + sumY + 
                  ", SumXY: " + sumXY + ", SumX2: " + sumX2 + ", n: " + n);
            
            // Calculate slope (m) and intercept (b)
            double denominator = (n * sumX2 - sumX * sumX);
            if (Math.abs(denominator) < 0.0001) {
                Log.e("TemperaturePrediction", "Cannot calculate regression: denominator too small: " + denominator);
                return null;
            }
            
            double m = (n * sumXY - sumX * sumY) / denominator;
            double b = (sumY - m * sumX) / n;
            
            Log.d("TemperaturePrediction", "Trained model: y = " + m + "x + " + b);
            Log.d("TemperaturePrediction", "Slope (m): " + m + ", Intercept (b): " + b);
            
            // Validate model parameters are reasonable
            if (Double.isNaN(m) || Double.isNaN(b) || Double.isInfinite(m) || Double.isInfinite(b)) {
                Log.e("TemperaturePrediction", "Invalid model parameters: m=" + m + ", b=" + b);
                return null;
            }
            
            TemperatureModel model = new TemperatureModel(m, b, System.currentTimeMillis(), n);
            
            // Save the model
            saveModel(model);
            
            Log.d("TemperaturePrediction", "Model training completed and saved successfully");
            return model;
            
        } catch (Exception e) {
            Log.e("TemperaturePrediction", "Error training model", e);
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Initialize cities list with default cities.
     */
    private void initializeCities() {
        cities = new ArrayList<>();
        cities.add(new City("Austin", "TX", 30.28, -97.76));
        cities.add(new City("New York", "NY", 40.71, -74.01));
        cities.add(new City("Los Angeles", "CA", 34.05, -118.24));
        cities.add(new City("Chicago", "IL", 41.88, -87.63));
        cities.add(new City("Houston", "TX", 29.76, -95.37));
        
        // Load saved current city or use first city
        String savedCity = prefs.getString(KEY_CURRENT_CITY, "Austin, TX");
        currentCity = cities.get(0);  // Default to first city
        for (City city : cities) {
            if (city.getDisplayName().equals(savedCity)) {
                currentCity = city;
                break;
            }
        }
        
        updateCityLabel();
    }
    
    /**
     * Show dialog to add or switch cities.
     */
    private void showCityManagementDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Manage Cities");
        
        // Create list of city names
        String[] cityNames = new String[cities.size() + 1];
        for (int i = 0; i < cities.size(); i++) {
            cityNames[i] = cities.get(i).getDisplayName();
        }
        cityNames[cities.size()] = "+ Add New City";
        
        builder.setItems(cityNames, (dialog, which) -> {
            if (which == cities.size()) {
                // Add new city
                showAddCityDialog();
            } else {
                // Switch to selected city
                City newCity = cities.get(which);
                // Clear cached model when switching cities
                if (currentCity != null && !newCity.getDisplayName().equals(currentCity.getDisplayName())) {
                    Log.d("TemperaturePrediction", "City changed from " + currentCity.getDisplayName() + 
                          " to " + newCity.getDisplayName() + ", clearing cached model");
                    cachedModel = null;
                }
                currentCity = newCity;
                prefs.edit().putString(KEY_CURRENT_CITY, currentCity.getDisplayName()).apply();
                updateCityLabel();
                // Load model for new city
                loadCachedModel();
                startForecastFetch();
            }
        });
        
        builder.show();
    }
    
    /**
     * Show dialog to add a new city.
     */
    private void showAddCityDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Add New City");
        
        final android.widget.EditText nameInput = new android.widget.EditText(this);
        nameInput.setHint("City Name");
        final android.widget.EditText stateInput = new android.widget.EditText(this);
        stateInput.setHint("State (e.g., TX)");
        final android.widget.EditText latInput = new android.widget.EditText(this);
        latInput.setHint("Latitude");
        final android.widget.EditText lonInput = new android.widget.EditText(this);
        lonInput.setHint("Longitude");
        
        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);
        layout.addView(nameInput);
        layout.addView(stateInput);
        layout.addView(latInput);
        layout.addView(lonInput);
        
        builder.setView(layout);
        builder.setPositiveButton("Add", (dialog, which) -> {
            try {
                String name = nameInput.getText().toString().trim();
                String state = stateInput.getText().toString().trim();
                double lat = Double.parseDouble(latInput.getText().toString());
                double lon = Double.parseDouble(lonInput.getText().toString());
                
                if (!name.isEmpty() && !state.isEmpty()) {
                    City newCity = new City(name, state, lat, lon);
                    cities.add(newCity);
                    // Clear cached model when adding/switching to new city
                    if (currentCity != null && !newCity.getDisplayName().equals(currentCity.getDisplayName())) {
                        Log.d("TemperaturePrediction", "City changed to new city, clearing cached model");
                        cachedModel = null;
                    }
                    currentCity = newCity;
                    prefs.edit().putString(KEY_CURRENT_CITY, currentCity.getDisplayName()).apply();
                    updateCityLabel();
                    // Load model for new city
                    loadCachedModel();
                    startForecastFetch();
                    Toast.makeText(this, "City added!", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
    
    /**
     * Update the city label display.
     */
    private void updateCityLabel() {
        if (currentCity != null) {
            cityLabel.setText(currentCity.getDisplayName().toUpperCase(Locale.US));
        }
    }

    /**
     * Initialize all view references from the layout.
     */
    private void initializeViews() {
        progressBar = findViewById(R.id.progressBar);
        errorTextView = findViewById(R.id.errorTextView);
        cityLabel = findViewById(R.id.cityLabel);
        todayBigTemp = findViewById(R.id.todayBigTemp);
        subtitleText = findViewById(R.id.subtitleText);
        refreshButton = findViewById(R.id.refreshButton);

        // Initialize arrays for day labels and temperatures
        dayLabels = new TextView[]{
            findViewById(R.id.day1Label),
            findViewById(R.id.day2Label),
            findViewById(R.id.day3Label),
            findViewById(R.id.day4Label),
            findViewById(R.id.day5Label),
            findViewById(R.id.day6Label),
            findViewById(R.id.day7Label)
        };

        dayTemps = new TextView[]{
            findViewById(R.id.day1Temp),
            findViewById(R.id.day2Temp),
            findViewById(R.id.day3Temp),
            findViewById(R.id.day4Temp),
            findViewById(R.id.day5Temp),
            findViewById(R.id.day6Temp),
            findViewById(R.id.day7Temp)
        };

        dayHumidities = new TextView[]{
            findViewById(R.id.day1Humidity),
            findViewById(R.id.day2Humidity),
            findViewById(R.id.day3Humidity),
            findViewById(R.id.day4Humidity),
            findViewById(R.id.day5Humidity),
            findViewById(R.id.day6Humidity),
            findViewById(R.id.day7Humidity)
        };

        dayWinds = new TextView[]{
            findViewById(R.id.day1Wind),
            findViewById(R.id.day2Wind),
            findViewById(R.id.day3Wind),
            findViewById(R.id.day4Wind),
            findViewById(R.id.day5Wind),
            findViewById(R.id.day6Wind),
            findViewById(R.id.day7Wind)
        };

        // Day cards for click handling
        dayCards = new View[]{
            findViewById(R.id.card1),
            findViewById(R.id.card2),
            findViewById(R.id.card3),
            findViewById(R.id.card4),
            findViewById(R.id.card5),
            findViewById(R.id.card6),
            findViewById(R.id.card7)
        };
        
        // Set click listeners on cards
        for (int i = 0; i < dayCards.length; i++) {
            final int dayIndex = i;
            dayCards[i].setOnClickListener(v -> openDetailedView(dayIndex));
        }

        // Prediction UI
        predictButton = findViewById(R.id.predictButton);
        predictionProgressBar = findViewById(R.id.predictionProgressBar);
        predictionTextView = findViewById(R.id.predictionTextView);
    }
    
    /**
     * Open detailed weather view for a specific day.
     */
    private void openDetailedView(int dayIndex) {
        if (currentForecasts == null || dayIndex >= currentForecasts.size()) {
            Toast.makeText(this, "Weather data not available", Toast.LENGTH_SHORT).show();
            return;
        }
        
        DailyForecast forecast = currentForecasts.get(dayIndex);
        if (forecast.hourlyData == null || forecast.hourlyData.isEmpty()) {
            Toast.makeText(this, "Hourly data not available for this day", Toast.LENGTH_SHORT).show();
            return;
        }
        
        Intent intent = new Intent(this, DetailedWeatherActivity.class);
        intent.putExtra("dayIndex", dayIndex);
        intent.putExtra("dayLabel", forecast.dateLabel);
        intent.putExtra("hourlyData", new ArrayList<>(forecast.hourlyData));
        startActivity(intent);
    }

    /**
     * Start the forecast fetch task.
     */
    private void startForecastFetch() {
        // Show progress bar and hide error
        progressBar.setVisibility(View.VISIBLE);
        errorTextView.setVisibility(View.GONE);
        refreshButton.setEnabled(false);
        
        // Dim the day cards initially
        for (TextView temp : dayTemps) {
            temp.setAlpha(0.5f);
        }
        
        // Execute the async task
        new FetchForecastTask().execute();
    }

    /**
     * Build the Open Meteo API URL for the current city with additional metrics.
     * @return The complete API URL string
     */
    private String buildForecastUrl() {
        if (currentCity == null) {
            currentCity = new City("Austin", "TX", 30.28, -97.76);
        }
        return "https://api.open-meteo.com/v1/forecast" +
                "?latitude=" + currentCity.latitude +
                "&longitude=" + currentCity.longitude +
                "&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m,rain,surface_pressure,visibility" +
                "&temperature_unit=fahrenheit" +
                "&windspeed_unit=mph" +
                "&forecast_days=7" +
                "&timezone=auto";
    }

    /**
     * Generate a human-friendly label for a day based on offset from today.
     * @param baseDate The base date (today)
     * @param offset Days offset from base (0 = today, 1 = tomorrow, etc.)
     * @return Label string like "Today", "Tomorrow", or "Wed 11 19"
     */
    private String labelForOffset(Calendar baseDate, int offset) {
        Calendar targetDate = (Calendar) baseDate.clone();
        targetDate.add(Calendar.DAY_OF_MONTH, offset);
        
        if (offset == 0) {
            return "Today";
        } else if (offset == 1) {
            return "Tomorrow";
        } else {
            // Format as "Wed 11 19" (day name, month, day)
            SimpleDateFormat formatter = new SimpleDateFormat("EEE M d", Locale.US);
            return formatter.format(targetDate.getTime());
        }
    }

    /**
     * AsyncTask to fetch forecast data from Open Meteo API.
     * Note: AsyncTask is deprecated in API 30+, but acceptable for this assignment (min SDK 24).
     */
    @SuppressWarnings("deprecation")
    private class FetchForecastTask extends AsyncTask<Void, Void, List<DailyForecast>> {
        private String errorMessage = null;

        @Override
        protected List<DailyForecast> doInBackground(Void... voids) {
            try {
                // Build URL and open connection
                URL url = new URL(buildForecastUrl());
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(10000); // 10 seconds
                connection.setReadTimeout(10000);

                // Check response code
                int responseCode = connection.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    errorMessage = "Server error: " + responseCode;
                    return null;
                }

                // Read response
                BufferedReader reader = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                connection.disconnect();

                // Parse JSON
                return parseForecastJson(response.toString());

            } catch (Exception e) {
                errorMessage = "Error fetching data: " + e.getMessage();
                e.printStackTrace();
                return null;
            }
        }

        /**
         * Parse the JSON response from Open Meteo API and compute daily averages.
         * @param jsonString The JSON response string
         * @return List of DailyForecast objects for the next 7 days
         */
        private List<DailyForecast> parseForecastJson(String jsonString) throws Exception {
            JSONObject root = new JSONObject(jsonString);
            JSONObject hourly = root.getJSONObject("hourly");
            
            JSONArray timeArray = hourly.getJSONArray("time");
            JSONArray tempArray = hourly.getJSONArray("temperature_2m");
            JSONArray humidityArray = hourly.optJSONArray("relative_humidity_2m");
            JSONArray windArray = hourly.optJSONArray("wind_speed_10m");
            JSONArray rainArray = hourly.optJSONArray("rain");
            JSONArray pressureArray = hourly.optJSONArray("surface_pressure");
            JSONArray visibilityArray = hourly.optJSONArray("visibility");

            // Group hourly values by date (yyyy-MM-dd) and store hourly data
            Map<String, List<Double>> dateToTemps = new HashMap<>();
            Map<String, List<Double>> dateToHumidities = new HashMap<>();
            Map<String, List<Double>> dateToWinds = new HashMap<>();
            Map<String, List<Double>> dateToRains = new HashMap<>();
            Map<String, List<HourlyWeatherData>> dateToHourlyData = new HashMap<>();
            
            for (int i = 0; i < timeArray.length() && i < tempArray.length(); i++) {
                String timeString = timeArray.getString(i);
                double temp = tempArray.getDouble(i);
                
                // Extract date part (first 10 characters: "yyyy-MM-dd")
                String dateKey = timeString.substring(0, 10);
                
                // Get optional values
                Double humidity = (humidityArray != null && i < humidityArray.length()) 
                    ? humidityArray.getDouble(i) : null;
                Double wind = (windArray != null && i < windArray.length()) 
                    ? windArray.getDouble(i) : null;
                Double rain = (rainArray != null && i < rainArray.length()) 
                    ? rainArray.getDouble(i) : null;
                Double pressure = (pressureArray != null && i < pressureArray.length()) 
                    ? pressureArray.getDouble(i) : null;
                Double visibility = (visibilityArray != null && i < visibilityArray.length()) 
                    ? visibilityArray.getDouble(i) : null;
                
                // Store hourly data
                if (!dateToHourlyData.containsKey(dateKey)) {
                    dateToHourlyData.put(dateKey, new ArrayList<>());
                }
                dateToHourlyData.get(dateKey).add(
                    new HourlyWeatherData(timeString, temp, humidity, wind, rain, pressure, visibility));
                
                // Temperature
                if (!dateToTemps.containsKey(dateKey)) {
                    dateToTemps.put(dateKey, new ArrayList<>());
                }
                dateToTemps.get(dateKey).add(temp);
                
                // Humidity
                if (humidity != null) {
                    if (!dateToHumidities.containsKey(dateKey)) {
                        dateToHumidities.put(dateKey, new ArrayList<>());
                    }
                    dateToHumidities.get(dateKey).add(humidity);
                }
                
                // Wind speed
                if (wind != null) {
                    if (!dateToWinds.containsKey(dateKey)) {
                        dateToWinds.put(dateKey, new ArrayList<>());
                    }
                    dateToWinds.get(dateKey).add(wind);
                }
                
                // Rain
                if (rain != null) {
                    if (!dateToRains.containsKey(dateKey)) {
                        dateToRains.put(dateKey, new ArrayList<>());
                    }
                    dateToRains.get(dateKey).add(rain);
                }
            }

            // Compute daily averages and create forecast list
            Calendar today = Calendar.getInstance();
            List<DailyForecast> forecasts = new ArrayList<>();
            
            // Get the first 7 unique dates in order
            List<String> sortedDates = new ArrayList<>(dateToTemps.keySet());
            sortedDates.sort(String::compareTo);
            
            // Limit to 7 days
            int daysToProcess = Math.min(7, sortedDates.size());
            
            for (int i = 0; i < daysToProcess; i++) {
                String dateKey = sortedDates.get(i);
                List<Double> temps = dateToTemps.get(dateKey);
                
                // Compute temperature average
                double tempSum = 0.0;
                for (Double temp : temps) {
                    tempSum += temp;
                }
                double avgTemp = tempSum / temps.size();
                
                // Compute humidity average
                Double avgHumidity = null;
                if (dateToHumidities.containsKey(dateKey)) {
                    List<Double> humidities = dateToHumidities.get(dateKey);
                    double humiditySum = 0.0;
                    for (Double h : humidities) {
                        humiditySum += h;
                    }
                    avgHumidity = humiditySum / humidities.size();
                }
                
                // Compute wind speed average
                Double avgWind = null;
                if (dateToWinds.containsKey(dateKey)) {
                    List<Double> winds = dateToWinds.get(dateKey);
                    double windSum = 0.0;
                    for (Double w : winds) {
                        windSum += w;
                    }
                    avgWind = windSum / winds.size();
                }
                
                // Compute rain average
                Double avgRain = null;
                if (dateToRains.containsKey(dateKey)) {
                    List<Double> rains = dateToRains.get(dateKey);
                    double rainSum = 0.0;
                    for (Double r : rains) {
                        rainSum += r;
                    }
                    avgRain = rainSum / rains.size();
                }
                
                // Generate label based on offset from today
                // Calculate offset by comparing date strings
                String todayDateStr = String.format(Locale.US, "%04d-%02d-%02d",
                    today.get(Calendar.YEAR),
                    today.get(Calendar.MONTH) + 1,
                    today.get(Calendar.DAY_OF_MONTH));
                
                int offset = 0;
                if (!dateKey.equals(todayDateStr)) {
                    // Calculate days difference
                    Calendar targetDate = Calendar.getInstance();
                    String[] parts = dateKey.split("-");
                    targetDate.set(Integer.parseInt(parts[0]),
                                 Integer.parseInt(parts[1]) - 1,
                                 Integer.parseInt(parts[2]));
                    
                    long diffMillis = targetDate.getTimeInMillis() - today.getTimeInMillis();
                    offset = (int) (diffMillis / (24 * 60 * 60 * 1000));
                }
                
                String label = labelForOffset(today, offset);
                List<HourlyWeatherData> hourlyDataForDay = dateToHourlyData.get(dateKey);
                forecasts.add(new DailyForecast(label, avgTemp, avgHumidity, avgWind, avgRain, hourlyDataForDay));
            }

            return forecasts;
        }

        @Override
        protected void onPostExecute(List<DailyForecast> forecasts) {
            // Hide progress bar and re-enable refresh button
            progressBar.setVisibility(View.GONE);
            refreshButton.setEnabled(true);

            if (forecasts == null || forecasts.isEmpty()) {
                // Show error message
                errorTextView.setText(errorMessage != null ? errorMessage : "Failed to load forecast data");
                errorTextView.setVisibility(View.VISIBLE);
                return;
            }

            // Hide error and bind data to UI
            errorTextView.setVisibility(View.GONE);
            currentForecasts = forecasts;  // Store for detailed view
            bindForecastData(forecasts);
        }
    }

    /**
     * Bind the forecast data to the UI views.
     * @param forecasts List of DailyForecast objects
     */
    private void bindForecastData(List<DailyForecast> forecasts) {
        if (forecasts == null || forecasts.isEmpty()) {
            return;
        }

        // Set today's large temperature (first forecast)
        DailyForecast todayForecast = forecasts.get(0);
        todayBigTemp.setText(String.format(Locale.US, "%.0f°", todayForecast.averageTempF));

        // Bind each day's data to the corresponding views
        int count = Math.min(forecasts.size(), dayLabels.length);
        for (int i = 0; i < count; i++) {
            DailyForecast forecast = forecasts.get(i);
            
            // Restore full opacity
            dayTemps[i].setAlpha(1.0f);
            
            // Set label and temperature
            if (dayLabels[i] != null) {
                dayLabels[i].setText(forecast.dateLabel);
            }
            if (dayTemps[i] != null) {
                dayTemps[i].setText(String.format(Locale.US, "%.1f°F", forecast.averageTempF));
            }
            
            // Set humidity
            if (dayHumidities[i] != null) {
                if (forecast.averageHumidity != null) {
                    dayHumidities[i].setText(String.format(Locale.US, "Humidity %.0f%%", forecast.averageHumidity));
                } else {
                    dayHumidities[i].setText("Humidity --");
                }
            }
            
            // Set wind speed
            if (dayWinds[i] != null) {
                if (forecast.averageWindSpeed != null) {
                    dayWinds[i].setText(String.format(Locale.US, "Wind %.1f mph", forecast.averageWindSpeed));
                } else {
                    dayWinds[i].setText("Wind --");
                }
            }
        }

        // Clear any remaining day cards if we have fewer than 7 forecasts
        for (int i = count; i < dayLabels.length; i++) {
            if (dayLabels[i] != null) {
                dayLabels[i].setText("--");
            }
            if (dayTemps[i] != null) {
                dayTemps[i].setText("--°F");
                dayTemps[i].setAlpha(0.5f);
            }
            if (dayHumidities[i] != null) {
                dayHumidities[i].setText("Humidity --");
            }
            if (dayWinds[i] != null) {
                dayWinds[i].setText("Wind --");
            }
        }
    }

    /**
     * Start the temperature prediction task.
     */
    private void startPrediction() {
        Log.d("TemperaturePrediction", "startPrediction() called");
        
        // Check if we have a valid cached model
        if (cachedModel != null && !cachedModel.isStale(MODEL_RETRAIN_DAYS)) {
            Log.d("TemperaturePrediction", "Using cached model for prediction");
            makePredictionWithModel(cachedModel);
            return;
        }
        
        // Need to train or retrain model
        Log.d("TemperaturePrediction", "No valid cached model, training new model");
        predictionProgressBar.setVisibility(View.VISIBLE);
        predictionTextView.setText("Training model...");
        predictButton.setEnabled(false);
        
        new PredictTemperatureTask().execute();
    }
    
    /**
     * Make prediction using an existing model (fast path).
     */
    private void makePredictionWithModel(TemperatureModel model) {
        try {
            Calendar tomorrow = Calendar.getInstance();
            tomorrow.add(Calendar.DAY_OF_YEAR, 1);
            int tomorrowDayOfYear = tomorrow.get(Calendar.DAY_OF_YEAR);
            
            double prediction = model.predict(tomorrowDayOfYear);
            
            Log.d("TemperaturePrediction", "Prediction using cached model: " + prediction + "°F for dayOfYear " + tomorrowDayOfYear);
            
            String resultText = String.format(Locale.US, 
                "Predicted tomorrow average: %.1f°F (experimental)", prediction);
            predictionTextView.setText(resultText);
            
        } catch (Exception e) {
            Log.e("TemperaturePrediction", "Error making prediction with cached model", e);
            predictionTextView.setText("Error: " + e.getMessage());
        }
    }

    /**
     * Build the Open Meteo API URL for historical weather data.
     * Uses the archive API endpoint for past data.
     * Fetches at least 120 days of past data to ensure we have 100+ data points.
     * @return The complete API URL string for historical data
     */
    private String buildHistoricalDataUrl() {
        if (currentCity == null) {
            currentCity = new City("Austin", "TX", 30.28, -97.76);
        }
        
        Calendar endDate = Calendar.getInstance();
        endDate.add(Calendar.DAY_OF_YEAR, -1); // Yesterday
        Calendar startDate = (Calendar) endDate.clone();
        startDate.add(Calendar.DAY_OF_YEAR, -120); // 120 days ago
        
        String startDateStr = String.format(Locale.US, "%04d-%02d-%02d", 
            startDate.get(Calendar.YEAR), startDate.get(Calendar.MONTH) + 1, startDate.get(Calendar.DAY_OF_MONTH));
        String endDateStr = String.format(Locale.US, "%04d-%02d-%02d",
            endDate.get(Calendar.YEAR), endDate.get(Calendar.MONTH) + 1, endDate.get(Calendar.DAY_OF_MONTH));
        
        // Use the archive API endpoint for historical data
        // According to Open Meteo docs: https://open-meteo.com/en/docs/historical-weather-api
        // Archive API format: archive-api.open-meteo.com/v1/archive
        // Required parameters: latitude, longitude, start_date, end_date, hourly
        // Note: Archive API returns temperature in Celsius (no temperature_unit parameter)
        // We'll convert to Fahrenheit after receiving the data
        // Timezone: Use UTC for reliability (always supported by API)
        String url = "https://archive-api.open-meteo.com/v1/archive" +
                "?latitude=" + currentCity.latitude +
                "&longitude=" + currentCity.longitude +
                "&hourly=temperature_2m" +
                "&start_date=" + startDateStr +
                "&end_date=" + endDateStr +
                "&timezone=UTC";
        
        Log.d("TemperaturePrediction", "Historical data URL: " + url);
        Log.d("TemperaturePrediction", "Date range: " + startDateStr + " to " + endDateStr + 
              " (" + (120) + " days)");
        return url;
    }
    
    /**
     * Test method to verify API call and model training.
     * This can be called manually for debugging.
     */
    private void testApiAndModel() {
        Log.d("TemperaturePrediction", "=== TEST: Starting API and Model Test ===");
        
        new Thread(() -> {
            try {
                // Test 1: Build URL
                String url = buildHistoricalDataUrl();
                Log.d("TemperaturePrediction", "TEST: URL built successfully: " + url);
                
                // Test 2: Fetch data
                FetchHistoricalDataTask fetchTask = new FetchHistoricalDataTask();
                List<HistoricalDataPoint> data = fetchTask.doInBackground();
                
                if (data == null || data.isEmpty()) {
                    Log.e("TemperaturePrediction", "TEST FAILED: No data returned. Error: " + 
                          (fetchTask.errorMessage != null ? fetchTask.errorMessage : "Unknown"));
                    return;
                }
                
                Log.d("TemperaturePrediction", "TEST: API call successful, received " + data.size() + " data points");
                
                // Test 3: Train model
                TemperatureModel model = trainModel(data);
                
                if (model == null) {
                    Log.e("TemperaturePrediction", "TEST FAILED: Model training failed");
                    return;
                }
                
                Log.d("TemperaturePrediction", "TEST: Model training successful");
                Log.d("TemperaturePrediction", "TEST: Model parameters - slope=" + model.slope + 
                      ", intercept=" + model.intercept);
                
                // Test 4: Make prediction
                Calendar tomorrow = Calendar.getInstance();
                tomorrow.add(Calendar.DAY_OF_YEAR, 1);
                int tomorrowDayOfYear = tomorrow.get(Calendar.DAY_OF_YEAR);
                double prediction = model.predict(tomorrowDayOfYear);
                
                Log.d("TemperaturePrediction", "TEST: Prediction successful - " + prediction + "°F for dayOfYear " + tomorrowDayOfYear);
                Log.d("TemperaturePrediction", "=== TEST: All tests passed ===");
                
            } catch (Exception e) {
                Log.e("TemperaturePrediction", "TEST FAILED: Exception occurred", e);
            }
        }).start();
    }

    /**
     * Data class to hold historical daily temperature data.
     */
    private static class HistoricalDataPoint {
        final int dayOfYear;
        final double temperature;
        final String date;

        HistoricalDataPoint(int dayOfYear, double temperature, String date) {
            this.dayOfYear = dayOfYear;
            this.temperature = temperature;
            this.date = date;
        }
    }

    /**
     * AsyncTask to fetch historical weather data from Open Meteo API.
     * Note: AsyncTask is deprecated in API 30+, but acceptable for this assignment (min SDK 24).
     */
    @SuppressWarnings("deprecation")
    private class FetchHistoricalDataTask extends AsyncTask<Void, Void, List<HistoricalDataPoint>> {
        String errorMessage = null;  // Package-private for access from PredictTemperatureTask

        @Override
        protected List<HistoricalDataPoint> doInBackground(Void... voids) {
            Log.d("TemperaturePrediction", "FetchHistoricalDataTask.doInBackground() started");
            try {
                // Build URL and open connection
                URL url = new URL(buildHistoricalDataUrl());
                Log.d("TemperaturePrediction", "Opening connection to: " + url.toString());
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(15000); // 15 seconds
                connection.setReadTimeout(15000);

                // Check response code
                int responseCode = connection.getResponseCode();
                Log.d("TemperaturePrediction", "Response code: " + responseCode);
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    // Read error response body for more details
                    String errorBody = "";
                    try {
                        BufferedReader errorReader = new BufferedReader(
                            new InputStreamReader(connection.getErrorStream()));
                        StringBuilder errorResponse = new StringBuilder();
                        String errorLine;
                        while ((errorLine = errorReader.readLine()) != null) {
                            errorResponse.append(errorLine);
                        }
                        errorReader.close();
                        errorBody = errorResponse.toString();
                        Log.e("TemperaturePrediction", "Error response body: " + errorBody);
                    } catch (Exception e) {
                        Log.e("TemperaturePrediction", "Could not read error stream", e);
                    }
                    
                    errorMessage = "Server error: " + responseCode;
                    if (!errorBody.isEmpty()) {
                        errorMessage += " - " + errorBody;
                    }
                    Log.e("TemperaturePrediction", "HTTP error: " + responseCode + ", message: " + errorMessage);
                    return null;
                }

                // Read response
                BufferedReader reader = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                connection.disconnect();

                Log.d("TemperaturePrediction", "Response received, length: " + response.length());
                
                // Parse JSON
                return parseHistoricalJson(response.toString());

            } catch (Exception e) {
                errorMessage = "Error fetching historical data: " + e.getMessage();
                Log.e("TemperaturePrediction", "Exception in FetchHistoricalDataTask", e);
                e.printStackTrace();
                return null;
            }
        }

        /**
         * Parse the JSON response and compute daily averages.
         * @param jsonString The JSON response string
         * @return List of HistoricalDataPoint objects with dayOfYear and temperature
         */
        private List<HistoricalDataPoint> parseHistoricalJson(String jsonString) throws Exception {
            Log.d("TemperaturePrediction", "parseHistoricalJson() started");
            JSONObject root = new JSONObject(jsonString);
            JSONObject hourly = root.getJSONObject("hourly");
            
            JSONArray timeArray = hourly.getJSONArray("time");
            JSONArray tempArray = hourly.getJSONArray("temperature_2m");

            Log.d("TemperaturePrediction", "Found " + timeArray.length() + " hourly data points");
            
            // Validate arrays have data
            if (timeArray.length() == 0 || tempArray.length() == 0) {
                throw new Exception("Empty data arrays from API");
            }
            
            if (timeArray.length() != tempArray.length()) {
                Log.w("TemperaturePrediction", "Array length mismatch: time=" + timeArray.length() + 
                      ", temp=" + tempArray.length());
            }

            // Group hourly values by date (yyyy-MM-dd)
            Map<String, List<Double>> dateToTemps = new HashMap<>();
            int validPoints = 0;
            int invalidPoints = 0;
            
            for (int i = 0; i < timeArray.length() && i < tempArray.length(); i++) {
                try {
                    String timeString = timeArray.getString(i);
                    
                    // Validate time string format
                    if (timeString == null || timeString.length() < 10) {
                        Log.w("TemperaturePrediction", "Invalid time string at index " + i + ": " + timeString);
                        invalidPoints++;
                        continue;
                    }
                    
                    double tempCelsius = tempArray.getDouble(i);
                    
                    // Validate temperature is reasonable (not NaN or infinite)
                    if (Double.isNaN(tempCelsius) || Double.isInfinite(tempCelsius)) {
                        Log.w("TemperaturePrediction", "Invalid temperature at index " + i + ": " + tempCelsius);
                        invalidPoints++;
                        continue;
                    }
                    
                    // Archive API returns temperature in Celsius, convert to Fahrenheit
                    double tempFahrenheit = (tempCelsius * 9.0 / 5.0) + 32.0;
                    
                    // Extract date part (first 10 characters: "yyyy-MM-dd")
                    String dateKey = timeString.substring(0, 10);
                    
                    if (!dateToTemps.containsKey(dateKey)) {
                        dateToTemps.put(dateKey, new ArrayList<>());
                    }
                    dateToTemps.get(dateKey).add(tempFahrenheit);
                    validPoints++;
                    
                } catch (Exception e) {
                    Log.w("TemperaturePrediction", "Error processing data point " + i + ": " + e.getMessage());
                    invalidPoints++;
                }
            }
            
            Log.d("TemperaturePrediction", "Processed " + validPoints + " valid points, " + invalidPoints + " invalid points");

            Log.d("TemperaturePrediction", "Grouped into " + dateToTemps.size() + " unique dates");
            
            if (dateToTemps.isEmpty()) {
                throw new Exception("No valid dates found in API response");
            }

            // Compute daily averages and create data points
            List<HistoricalDataPoint> dataPoints = new ArrayList<>();
            Calendar cal = Calendar.getInstance();
            
            // Get sorted dates
            List<String> sortedDates = new ArrayList<>(dateToTemps.keySet());
            sortedDates.sort(String::compareTo);
            
            Log.d("TemperaturePrediction", "Date range: " + sortedDates.get(0) + " to " + 
                  sortedDates.get(sortedDates.size() - 1));
            
            for (String dateKey : sortedDates) {
                try {
                    List<Double> temps = dateToTemps.get(dateKey);
                    
                    if (temps == null || temps.isEmpty()) {
                        Log.w("TemperaturePrediction", "No temperatures for date: " + dateKey);
                        continue;
                    }
                    
                    // Compute average
                    double sum = 0.0;
                    for (Double temp : temps) {
                        if (temp != null && !Double.isNaN(temp) && !Double.isInfinite(temp)) {
                            sum += temp;
                        }
                    }
                    double avgTemp = sum / temps.size();
                    
                    // Validate average is reasonable
                    if (Double.isNaN(avgTemp) || Double.isInfinite(avgTemp)) {
                        Log.w("TemperaturePrediction", "Invalid average for date: " + dateKey);
                        continue;
                    }
                    
                    // Calculate day of year
                    String[] parts = dateKey.split("-");
                    if (parts.length != 3) {
                        Log.w("TemperaturePrediction", "Invalid date format: " + dateKey);
                        continue;
                    }
                    
                    cal.set(Integer.parseInt(parts[0]),
                           Integer.parseInt(parts[1]) - 1,
                           Integer.parseInt(parts[2]));
                    int dayOfYear = cal.get(Calendar.DAY_OF_YEAR);
                    
                    dataPoints.add(new HistoricalDataPoint(dayOfYear, avgTemp, dateKey));
                    
                } catch (Exception e) {
                    Log.w("TemperaturePrediction", "Error processing date " + dateKey + ": " + e.getMessage());
                }
            }

            Log.d("TemperaturePrediction", "Created " + dataPoints.size() + " historical data points");
            
            // Log statistics
            if (!dataPoints.isEmpty()) {
                double minTemp = dataPoints.get(0).temperature;
                double maxTemp = dataPoints.get(0).temperature;
                double sumTemp = 0;
                for (HistoricalDataPoint point : dataPoints) {
                    minTemp = Math.min(minTemp, point.temperature);
                    maxTemp = Math.max(maxTemp, point.temperature);
                    sumTemp += point.temperature;
                }
                double avgTemp = sumTemp / dataPoints.size();
                Log.d("TemperaturePrediction", "Temperature stats - Min: " + minTemp + "°F, Max: " + 
                      maxTemp + "°F, Avg: " + avgTemp + "°F");
            }
            
            return dataPoints;
        }
    }

    /**
     * AsyncTask to train model and predict tomorrow's temperature.
     * Note: AsyncTask is deprecated in API 30+, but acceptable for this assignment (min SDK 24).
     */
    @SuppressWarnings("deprecation")
    private class PredictTemperatureTask extends AsyncTask<Void, Void, TemperatureModel> {
        private String errorMessage = null;

        @Override
        protected TemperatureModel doInBackground(Void... voids) {
            Log.d("TemperaturePrediction", "PredictTemperatureTask.doInBackground() started");
            try {
                // Step 1: Fetch historical data
                Log.d("TemperaturePrediction", "Step 1: Fetching historical data from API");
                FetchHistoricalDataTask fetchTask = new FetchHistoricalDataTask();
                List<HistoricalDataPoint> historicalData = fetchTask.doInBackground();
                
                if (historicalData == null || historicalData.isEmpty()) {
                    errorMessage = fetchTask.errorMessage != null ? fetchTask.errorMessage : "No historical data available";
                    Log.e("TemperaturePrediction", "No historical data: " + errorMessage);
                    return null;
                }
                
                Log.d("TemperaturePrediction", "API returned " + historicalData.size() + " historical data points");
                
                // Validate data quality
                if (historicalData.size() < 100) {
                    errorMessage = "Insufficient data: only " + historicalData.size() + " points (need 100+)";
                    Log.e("TemperaturePrediction", errorMessage);
                    return null;
                }
                
                // Log sample data points for verification
                Log.d("TemperaturePrediction", "Sample data points (first 5):");
                for (int i = 0; i < Math.min(5, historicalData.size()); i++) {
                    HistoricalDataPoint point = historicalData.get(i);
                    Log.d("TemperaturePrediction", "  [" + i + "] dayOfYear=" + point.dayOfYear + 
                          ", temp=" + point.temperature + "°F, date=" + point.date);
                }
                
                // Step 2: Train model
                Log.d("TemperaturePrediction", "Step 2: Training model");
                TemperatureModel model = trainModel(historicalData);
                
                if (model == null) {
                    errorMessage = "Model training failed";
                    Log.e("TemperaturePrediction", errorMessage);
                    return null;
                }
                
                Log.d("TemperaturePrediction", "Model trained successfully: slope=" + model.slope + 
                      ", intercept=" + model.intercept);
                
                return model;
                
            } catch (Exception e) {
                errorMessage = "Prediction error: " + e.getMessage();
                Log.e("TemperaturePrediction", "Exception in PredictTemperatureTask", e);
                e.printStackTrace();
                if (e.getCause() != null) {
                    Log.e("TemperaturePrediction", "Cause: " + e.getCause().getMessage(), e.getCause());
                    errorMessage += " (Cause: " + e.getCause().getMessage() + ")";
                }
                return null;
            }
        }

        @Override
        protected void onPostExecute(TemperatureModel model) {
            Log.d("TemperaturePrediction", "onPostExecute() called with model: " + (model != null ? "valid" : "null"));
            predictionProgressBar.setVisibility(View.GONE);
            predictButton.setEnabled(true);
            
            if (model == null) {
                String errorMsg = errorMessage != null ? errorMessage : "Model training failed";
                Log.e("TemperaturePrediction", "Prediction failed: " + errorMsg);
                predictionTextView.setText("Error: " + errorMsg);
                return;
            }
            
            // Make prediction using the trained model
            makePredictionWithModel(model);
        }
    }
}
