package com.example.assignment5;

import java.util.List;

/**
 * Data model representing a daily weather forecast.
 */
public class DailyForecast {
    public final String dateLabel;      // "Today", "Tomorrow", or formatted date
    public final double averageTempF;   // daily average in Fahrenheit
    public final Double averageHumidity;    // nullable if not available (percentage)
    public final Double averageWindSpeed;   // nullable if not available (mph)
    public final Double averageRain;        // nullable if not available (mm)
    public final List<HourlyWeatherData> hourlyData;  // Hourly data for this day

    public DailyForecast(String dateLabel, double averageTempF) {
        this.dateLabel = dateLabel;
        this.averageTempF = averageTempF;
        this.averageHumidity = null;
        this.averageWindSpeed = null;
        this.averageRain = null;
        this.hourlyData = null;
    }

    public DailyForecast(String dateLabel, double averageTempF, Double averageHumidity, 
                        Double averageWindSpeed, Double averageRain, List<HourlyWeatherData> hourlyData) {
        this.dateLabel = dateLabel;
        this.averageTempF = averageTempF;
        this.averageHumidity = averageHumidity;
        this.averageWindSpeed = averageWindSpeed;
        this.averageRain = averageRain;
        this.hourlyData = hourlyData;
    }
}

